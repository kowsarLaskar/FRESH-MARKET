<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout</title>
</head>
<?php require_once '../views/inc/header.php'; ?>
<body>
  <h1>
    Checkout Page
  </h1>
  <br>
  <p>
    This is the checkout page. You can implement the checkout process here.
  </p>
</body>
<?php require_once '../views/includes/footer.php'; ?>
</html>