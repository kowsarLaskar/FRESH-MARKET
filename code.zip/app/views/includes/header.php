<?php
// 1. Get the current URL path to check which page is active
$uri = $_SERVER['REQUEST_URI'];

// 2. Define Active States
// Check if URL contains specific keywords
$shop_active    = (strpos($uri, '/shop') !== false) ? 'active' : '';
$about_active   = (strpos($uri, '/about') !== false) ? 'active' : '';
$contact_active = (strpos($uri, '/contact') !== false) ? 'active' : '';

// Home is active if we are NOT on any other known page (Shop, Admin, Users, Cart, etc.)
$home_active = '';
if (
    $shop_active == '' && $about_active == '' && $contact_active == '' &&
    strpos($uri, '/admin') === false &&
    strpos($uri, '/users') === false &&
    strpos($uri, '/cart') === false &&
    strpos($uri, '/orders') === false
) {
    $home_active = 'active';
}

// 3. Calculate Cart Count
$cart_count = isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'qty')) : 0;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITENAME; ?></title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary-green: #2A6049;
            --bg-cream: #FBF9F1;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-cream);
            color: var(--primary-green);
        }

        /* --- NAVBAR STYLING --- */
        .custom-navbar {
            background-color: var(--bg-cream);
            padding: 1rem 0;
            /* Increased padding to accommodate bigger logo */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .navbar-brand {
            display: flex;
            align-items: center;
            padding: 0;
            text-decoration: none;
            mix-blend-mode: multiply;
        }

        /* Logo sizing - Increased height */
        .navbar-brand img {
            height: 85px;
            /* Increased from 60px */
            width: auto;
            object-fit: contain;
        }

        /* New Text Styling next to logo */
        .brand-text {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-green);
            margin-left: 5px;
            letter-spacing: 1px;
            /* Ensures text doesn't wrap awkwardly on very small screens */
            white-space: nowrap;
        }

        .nav-link {
            color: #555;
            font-weight: 400;
            margin: 0 15px;
            transition: color 0.3s;
        }

        .nav-link:hover,
        .nav-link.active {
            color: var(--primary-green) !important;
            font-weight: 600;
        }

        .icon-btn {
            color: var(--primary-green);
            font-size: 1.2rem;
            text-decoration: none;
            position: relative;
        }

        .cart-badge {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -10%);
            color: white;
            font-size: 0.6rem;
            font-weight: bold;
        }

        .offcanvas {
            background-color: var(--bg-cream);
            width: 80% !important;
        }

        .mobile-nav-link {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-green);
            text-decoration: none;
            display: block;
            margin-bottom: 20px;
            opacity: 0.7;
        }

        .mobile-nav-link.active {
            opacity: 1;
            text-decoration: underline;
        }

        .mobile-login {
            font-size: 1.2rem;
            color: var(--primary-green);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 40px;
        }

        .navbar-toggler {
            border: none;
            padding: 0;
            color: var(--primary-green);
            font-size: 1.5rem;
        }

        .navbar-toggler:focus {
            box-shadow: none;
        }

        @media (min-width: 992px) {
            .centered-nav {
                position: absolute;
                left: 50%;
                transform: translateX(-50%);
                margin: 0;
            }
        }

        /* Responsive adjustments for smaller screens to prevent overlap */
        @media (max-width: 1200px) and (min-width: 992px) {
            .brand-text {
                font-size: 1.4rem;
            }

            .navbar-brand img {
                height: 70px;
            }

            .nav-link {
                margin: 0 5px;
            }
        }

        @media (max-width: 576px) {
            .brand-text {
                font-size: 1.2rem;
                margin-left: 10px;
            }

            .navbar-brand img {
                height: 60px;
            }
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg custom-navbar sticky-top">
        <div class="container-fluid px-3 px-lg-5 d-block">
            <div class="d-flex justify-content-between align-items-center w-100 position-relative">

                <a class="navbar-brand" href="<?php echo URLROOT; ?>">
                    <img src="<?php echo URLROOT; ?>/assets/hero_images/fresh-market-logo.png" alt="Fresh Market Logo">
                    <span class="brand-text">Fresh Market</span>
                </a>

                <div class="d-flex align-items-center d-lg-none gap-3">
                    <a href="<?php echo URLROOT; ?>/cart" class="icon-btn">
                        <i class="fas fa-shopping-bag fa-lg"></i>
                        <span class="cart-badge" id="mobile-cart-count"><?php echo $cart_count; ?></span>
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu">
                        <i class="fas fa-bars"></i>
                    </button>
                </div>

                <div class="collapse navbar-collapse" id="desktopMenu">
                    <ul class="navbar-nav centered-nav">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $home_active; ?>" href="<?php echo URLROOT; ?>">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $shop_active; ?>" href="<?php echo URLROOT; ?>/shop">Shop</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $about_active; ?>" href="<?php echo URLROOT; ?>/Pages/about">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $contact_active; ?>" href="<?php echo URLROOT; ?>/Pages/contact">Contact</a>
                        </li>
                    </ul>

                    <div class="d-flex align-items-center gap-4 ms-auto">
                        <a href="#" class="icon-btn"><i class="fas fa-search"></i></a>

                        <?php if (isset($_SESSION['user_id'])): ?>
                            <div class="dropdown">
                                <a href="#" class="icon-btn d-flex align-items-center gap-2" data-bs-toggle="dropdown">
                                    <i class="fas fa-user-check"></i>
                                    <span style="font-size:1rem;">Hi, <?php echo explode(' ', $_SESSION['user_name'])[0]; ?></span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end border-0 shadow">
                                    <?php if ($_SESSION['user_role'] == 'admin'): ?>
                                        <li><a class="dropdown-item" href="<?php echo URLROOT; ?>/admin">Dashboard</a></li>
                                    <?php elseif ($_SESSION['user_role'] == 'delivery_boy'): ?>
                                        <li><a class="dropdown-item" href="<?php echo URLROOT; ?>/delivery">Delivery Panel</a></li>
                                    <?php endif; ?>
                                    <li><a class="dropdown-item" href="<?php echo URLROOT; ?>/orders">My Orders</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item text-danger" href="<?php echo URLROOT; ?>/users/logout">Logout</a></li>
                                </ul>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo URLROOT; ?>/users/login" class="icon-btn d-flex align-items-center gap-2">
                                <i class="fas fa-user-circle"></i> <span style="font-size:1rem;">Log In</span>
                            </a>
                        <?php endif; ?>

                        <a href="<?php echo URLROOT; ?>/cart" class="icon-btn">
                            <i class="fas fa-shopping-bag fa-lg"></i>
                            <span class="cart-badge" id="cart-count"><?php echo $cart_count; ?></span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="d-lg-none mt-2">
                <a href="#" class="icon-btn">
                    <i class="fas fa-search"></i>
                </a>
            </div>
        </div>
    </nav>

    <div class="offcanvas offcanvas-end" tabindex="-1" id="mobileMenu">
        <div class="offcanvas-header justify-content-end">
            <button type="button" class="btn-close fa-2x" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body px-4">

            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="mb-4">
                    <div class="text-muted small mb-1">Signed in as</div>
                    <div class="fw-bold text-success mb-3"><?php echo $_SESSION['user_name']; ?></div>

                    <?php if ($_SESSION['user_role'] == 'admin'): ?>
                        <a href="<?php echo URLROOT; ?>/admin" class="mobile-login mb-2">
                            <i class="fas fa-th-large"></i> Dashboard
                        </a>
                    <?php endif; ?>

                    <a href="<?php echo URLROOT; ?>/users/logout" class="mobile-login text-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            <?php else: ?>
                <a href="<?php echo URLROOT; ?>/users/login" class="mobile-login">
                    <i class="fas fa-user-circle fa-lg"></i> Log In
                </a>
            <?php endif; ?>

            <div class="d-flex flex-column border-top pt-4">
                <a href="<?php echo URLROOT; ?>"
                    class="mobile-nav-link <?php echo ($home_active == 'active') ? 'active text-success' : ''; ?>">Home</a>
                <a href="<?php echo URLROOT; ?>/shop"
                    class="mobile-nav-link <?php echo ($shop_active == 'active') ? 'active text-success' : ''; ?>">Shop</a>
                <a href="#"
                    class="mobile-nav-link <?php echo ($about_active == 'active') ? 'active text-success' : ''; ?>">About</a>
                <a href="#"
                    class="mobile-nav-link <?php echo ($contact_active == 'active') ? 'active text-success' : ''; ?>">Contact</a>
            </div>
        </div>
    </div>

    <div class="container-fluid px-0">